## -----------------------------------------------------------------------------
#install.packages("chemin/vers/mixturemodel_0.1.0.tar.gz", repos = NULL, type = "source")

## -----------------------------------------------------------------------------
library(mixturemodel)

## -----------------------------------------------------------------------------

generate_clusters<-function(n, d, prop){
  
n_out <- round(n * prop_outlier)
n1 <- round((n - n_out) / 2)
n2 <- n - n_out - n1

# -----------------------
# Cluster gaussien 1
mu1 <- c(0, 0)
sigma1 <- matrix(c(1, 0.2,
                   0.2, 1.5), 2, 2)
X1 <- MASS::mvrnorm(n1, mu1, sigma1)

# Cluster gaussien 2
mu2 <- c(6, 4)
sigma2 <- matrix(c(1.2, -0.1,
                   -0.1, 0.8), 2, 2)
X2 <- MASS::mvrnorm(n2, mu2, sigma2)

# -----------------------
# Outliers (loi uniforme)
Xout <- cbind(
  runif(n_out, min = -8, max = 12),
  runif(n_out, min = -6, max = 10)
)

# -----------------------
# Données finales
X <- rbind(X1, X2, Xout)
return(X)
 }

## -----------------------------------------------------------------------------
set.seed(123)

n <- 800      
d <- 2
prop_outlier <- 0.1

X_1<-generate_clusters(n, d, prop_outlier)

## -----------------------------------------------------------------------------
set.seed(123)

n <- 800      
d <- 2
prop_outlier <- 0.3

X_2<-generate_clusters(n, d, prop_outlier)

## -----------------------------------------------------------------------------
model_1<-MixtureModel(X_1, K=2, initialization_steps = 20)
model_2<-MixtureModel(X_2)

## -----------------------------------------------------------------------------
model_1<-fit(model_1)

## -----------------------------------------------------------------------------
model_2<-fit(model_2)

## -----------------------------------------------------------------------------
tail(model_1$proba)

## -----------------------------------------------------------------------------
tail(model_1$params)

## -----------------------------------------------------------------------------
model_1$bic

## -----------------------------------------------------------------------------
plot(
  unlist(model_1$likehood_values),
  type = "l",                
  col = "blue",
  lwd = 2,
  xlab = "Itérations",
  ylab = "Log-vraisemblance",
  main = "Évolution de la log-vraisemblance (EM)"
)
grid()

## -----------------------------------------------------------------------------
plot(
  model_2$bic_values,
  type = "p",         
  col = "blue",
  lwd = 2,
  xlab = "K",
  ylab = "BIC",
  main = "Évolution du BIC"
)
grid()

## -----------------------------------------------------------------------------
library(ggplot2)

df_1 <- data.frame(
  x = model_1$data[,1],
  y = model_1$data[,2],
  cluster = model_1$preds
)
ggplot(data = df_1, aes(x=x, y=y, color=cluster))+
  geom_point(size=2)+
  theme_minimal()

## -----------------------------------------------------------------------------
df_2 <- data.frame(
  x = model_2$data[,1],
  y = model_2$data[,2],
  cluster = model_2$preds
)
ggplot(data = df_2, aes(x=x, y=y, color=cluster))+
  geom_point(size=2)+
  theme_minimal()

## -----------------------------------------------------------------------------
library(MASS)
set.seed(123)
n_clusters <- 3
d <- 30     
points_per_cluster <- 150
outliers <- 50

means <- lapply(1:n_clusters, function(i) runif(d, -5, 5))
covs <- lapply(1:n_clusters, function(i) diag(runif(d, 0.5, 1.5)))

# Génération clusters
X <- do.call(rbind, lapply(1:n_clusters, function(k) {
  mvrnorm(points_per_cluster, mu = means[[k]], Sigma = covs[[k]])
}))

# Génération d'outliers uniformes
X_out <- matrix(runif(outliers*d, min=-10, max=10), ncol=d)
X<- rbind(X, X_out)

## -----------------------------------------------------------------------------
tail(X)

## -----------------------------------------------------------------------------
norm_X<- scale(X)
tail(norm_X)

## -----------------------------------------------------------------------------
norm_model<-MixtureModel(norm_X)
norm_model<-fit(norm_model)

## -----------------------------------------------------------------------------
plot(
  unlist(norm_model$likehood_values),
  type = "l",                
  col = "blue",
  lwd = 2,
  xlab = "Itérations",
  ylab = "Log-vraisemblance",
  main = "Évolution de la log-vraisemblance (EM)"
)
grid()

## -----------------------------------------------------------------------------
plot(
  norm_model$bic_values,
  type = "p",               
  col = "blue",
  lwd = 2,
  xlab = "K",
  ylab = "BIC",
  main = "Évolution du BIC"
)
grid()

