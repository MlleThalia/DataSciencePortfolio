## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(mixturemodel)

## -----------------------------------------------------------------------------
#install.packages("chemin/vers/ton_package_0.1.0.tar.gz", repos = NULL, type = "source")

## -----------------------------------------------------------------------------
#data=iris[, -5]
set.seed(123)

# --- Cluster 1 ---
x1 <- cbind(rnorm(100, mean = 0, sd = 0.5),
            rnorm(100, mean = 0, sd = 0.5))

# --- Cluster 2 ---
x2 <- cbind(rnorm(100, mean = 5, sd = 0.5),
            rnorm(100, mean = 5, sd = 0.5))

# --- Outlier ---
outlier <- matrix(c(10, 0), ncol = 2)  # très éloigné des autres points

# --- Jeu de données complet ---
x <- rbind(x1, x2, outlier)
colnames(x) <- c("X1", "X2")

normalize_zscore <- function(x) {
  x_norm <- scale(x)  # centre (mean=0) et réduit (sd=1) chaque colonne
  return(x_norm)
}

# Exemple
x <- normalize_zscore(x)

# --- Visualisation ---
plot(x, col = "grey40", pch = 19, main = "Données simulées avec un outlier")
points(outlier[,1], outlier[,2], col = "red", pch = 19, cex = 1.5)


## -----------------------------------------------------------------------------
mm_model<-MixtureModel(x, K=3)

## -----------------------------------------------------------------------------
mm_model<-fit(mm_model)

## -----------------------------------------------------------------------------
tail(mm_model$proba)

## -----------------------------------------------------------------------------
tail(mm_model$params)

## -----------------------------------------------------------------------------
mm_model$bic

## -----------------------------------------------------------------------------
plot(
  unlist(mm_model$likehood_values),
  type = "l",                 # "l" pour ligne
  col = "blue",
  lwd = 2,
  xlab = "Itérations",
  ylab = "Log-vraisemblance",
  main = "Évolution de la log-vraisemblance (EM)"
)
grid()

## -----------------------------------------------------------------------------
plot(
  mm_model$bic_values,
  type = "p",                 # "l" pour ligne
  col = "blue",
  lwd = 2,
  xlab = "K",
  ylab = "BIC",
  main = "Évolution du BIC"
)
grid()

## -----------------------------------------------------------------------------
library(ggplot2)

ggplot(data = mm_model$data, aes(x=mm_model$data[, 1], y=mm_model$data[, 2], color=mm_model$preds))+
  geom_point(size=3)

